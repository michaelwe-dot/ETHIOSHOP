import React from 'react';
import Listings from './pages/Listings';

export default function App() {
  return (
    <div>
      <h1>ETHIO Admin Panel</h1>
      <Listings />
    </div>
  );
}
